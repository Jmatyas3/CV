# slepchenko.github.io
My CV, public version
http://sliepchenko.github.io/
